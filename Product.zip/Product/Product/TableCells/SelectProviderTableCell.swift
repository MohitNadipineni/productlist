//
//  SelectProviderTableCell.swift
//  Product
//
//  Created by Mohit
//

import Foundation
import UIKit


class SelectProviderTableCell : UITableViewCell {
    
    @IBOutlet weak var lblTitle : UILabel!
    @IBOutlet weak var vwSelection : UIView!
    
    var provider : ProviderTable!{
        didSet{
            self.lblTitle.text = self.provider.name
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.vwSelection.layer.cornerRadius = self.vwSelection.frame.height / 2.0
        self.vwSelection.clipsToBounds = true
    }
    
}
