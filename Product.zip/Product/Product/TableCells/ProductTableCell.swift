//
//  ProductTableCell.swift
//  Product
//
//  Created by Mohit
//

import Foundation
import UIKit

class ProductTableCell : UITableViewCell{
    
    @IBOutlet weak var lblName : UILabel!
    @IBOutlet weak var lblProductPrice : UILabel!
    @IBOutlet weak var lblProductDescription : UILabel!
    @IBOutlet weak var lblProvider : UILabel!
    
    var product : ProductTable!{
        didSet{
            self.setData()
        }
    }
    
    func setData(){
        self.lblName.text = self.product.name
        self.lblProductPrice.text = "$ \(self.product.price ?? "")"
        self.lblProductDescription.text = self.product.productDetail
        self.lblProvider.text = "Provided by \(self.product.provider?.name ?? "")"
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
        self.lblProductDescription.numberOfLines = 2
    }
    
    
}
