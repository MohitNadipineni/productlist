//
//  ProviderTableCell.swift
//  Product
//
//  Created by Mohit
//

import Foundation
import UIKit


class ProviderTableCell : UITableViewCell{
    
    @IBOutlet weak var lblProviderName : UILabel!
    @IBOutlet weak var lblProducts : UILabel!
    
    
    var provider : ProviderTable!{
        didSet{
            self.lblProviderName.text = self.provider.name
            if let products = self.provider.product?.allObjects as? [ProductTable]{
                self.lblProducts.text = products.compactMap({$0.name ?? ""}).joined(separator: ", ")
                if self.lblProducts.text == ""{
                    self.lblProducts.text = "No products"
                }
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
        self.lblProducts.numberOfLines = 0
    }
    
}
