//
//  ProviderTable+CoreDataClass.swift
//  Product
//
//  Created by Mohit
//
//

import Foundation
import CoreData

@objc(ProviderTable)
public class ProviderTable: NSManagedObject {

}
