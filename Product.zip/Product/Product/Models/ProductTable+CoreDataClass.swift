//
//  ProductTable+CoreDataClass.swift
//  Product
//
//  Created by Mohit
//
//

import Foundation
import CoreData

@objc(ProductTable)
public class ProductTable: NSManagedObject {

}
