//
//  ProductTable+CoreDataProperties.swift
//  Product
//
//  Created by Mohit
//
//

import Foundation
import CoreData


extension ProductTable {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<ProductTable> {
        return NSFetchRequest<ProductTable>(entityName: "ProductTable")
    }

    @NSManaged public var price: String?
    @NSManaged public var productDetail: String?
    @NSManaged public var name: String?
    @NSManaged public var provider: ProviderTable?

}
