//
//  ProviderTable+CoreDataProperties.swift
//  Product
//
//  Created by Mohit
//
//

import Foundation
import CoreData


extension ProviderTable {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<ProviderTable> {
        return NSFetchRequest<ProviderTable>(entityName: "ProviderTable")
    }

    @NSManaged public var name: String?
    @NSManaged public var product: NSSet?

}

// MARK: Generated accessors for product
extension ProviderTable {

    @objc(addProductObject:)
    @NSManaged public func addToProduct(_ value: ProductTable)

    @objc(removeProductObject:)
    @NSManaged public func removeFromProduct(_ value: ProductTable)

    @objc(addProduct:)
    @NSManaged public func addToProduct(_ values: NSSet)

    @objc(removeProduct:)
    @NSManaged public func removeFromProduct(_ values: NSSet)

}
