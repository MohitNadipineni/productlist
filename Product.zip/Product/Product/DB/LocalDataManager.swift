//
//  LocalDataManager.swift
//  Product
//
//  Created by SOTSYS136 on 5/26/21.
//

import Foundation
import CoreData


class LocalDataManager {
    
    static let shared = LocalDataManager()
    
    var isLauch = "isLaunch"
    
    // MARK: - Core Data stack

      lazy var persistentContainer: NSPersistentContainer = {
          
          let container = NSPersistentContainer(name: "Product")
          container.loadPersistentStores(completionHandler: { (storeDescription, error) in
              if let error = error as NSError? {
                  fatalError("Unresolved error \(error), \(error.userInfo)")
              }
          })
          return container
      }()
    
    lazy var context = persistentContainer.viewContext

      // MARK: - Core Data Saving support

      func saveContext () {
          let context = persistentContainer.viewContext
          if context.hasChanges {
              do {
                  try context.save()
              } catch {
                  let nserror = error as NSError
                  fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
              }
          }
      }
    
    
    func addNewProvider(_ name:String) -> ProviderTable{
        let objProvider = ProviderTable(context: self.context)
        objProvider.name = name
        self.saveContext()
        return objProvider
    }
    
    var providers : [ProviderTable]{
        let req = NSFetchRequest<NSFetchRequestResult>(entityName: "ProviderTable")
        do {
            if let allProviders = try context.fetch(req) as? [ProviderTable]{
                return allProviders
            }
        }catch{
            print("Error while fetching",error.localizedDescription)
        }
        return []
    }
    
    
    @discardableResult func saveProduct(name:String,price:String,provider:ProviderTable,description:String) -> ProductTable{
        let objProduct = ProductTable(context: self.context)
        objProduct.name = name
        objProduct.price = price
        objProduct.productDetail = description
        objProduct.provider = provider
        saveContext()
        return objProduct
    }
    
    var products : [ProductTable]{
        let fetchReq = NSFetchRequest<NSFetchRequestResult>(entityName: "ProductTable")
        do {
            if let allProducts = try context.fetch(fetchReq) as? [ProductTable]{
                return allProducts
            }
        }catch{
            print("Error while fetching",error.localizedDescription)
        }
        return []
    }
    
    func setInitialData(){
        if !UserDefaults.standard.bool(forKey: isLauch){
            let objProvider = self.addNewProvider("Shailesh")
            self.addNewProvider("Ranmesh")
            self.addNewProvider("John")
            self.addNewProvider("Carter")
            let productName = "product test"
            let description = "Lorem ipsum dollar is static text used in the industry"
            let price = "190"
            self.saveProduct(name: productName, price: price, provider: objProvider, description: description)            
        }
        UserDefaults.standard.setValue(true, forKey: isLauch)
    }
    
}
