//
//  NewProductVC.swift
//  Product
//
//  Created by Mohit
//

import UIKit

class NewProductVC: UIViewController {

    //MARK:- Outlets
    @IBOutlet weak var txtName : UITextField!
    @IBOutlet weak var txtPrice : UITextField!
    @IBOutlet weak var txtProvider : UITextField!
    @IBOutlet weak var tvDescription : UITextView!
    @IBOutlet weak var vwEdit : UIStackView!
    @IBOutlet weak var btnAdd : UIButton!
    @IBOutlet weak var lblTitle : UILabel!
    
    //MARK:- Class Variables
    var provider : ProviderTable!
    var productDetail : ProductTable!
    
    //MARK:- Custom Methods
    
    func setUp(){
        
        self.txtProvider.delegate = self
        
        self.txtPrice.keyboardType = .decimalPad
        
        if productDetail != nil{
            self.setData()
        }else{
            self.vwEdit.isHidden = true
        }
    }
    
    func setData(){
        self.txtName.text = productDetail.name
        self.txtPrice.text = productDetail.price
        self.txtProvider.text = productDetail.provider?.name
        self.provider = productDetail.provider
        self.tvDescription.text = productDetail.productDetail
        
        self.btnAdd.isHidden = true
        self.lblTitle.text = "Update Detail"
    }
    
    func validateView() -> String?{
        if self.txtName.text == ""{
            return "Please enter name"
        }else if self.txtPrice.text == ""{
            return "Please enter price"
        }else if self.txtProvider.text == ""{
            return "Please select provider"
        }else if self.tvDescription.text == ""{
            return "Please enter description"
        }
        
        return nil
    }
    
    //MARK:- Click Events
    
    @IBAction func btnAddClicked(_ sender : UIButton){
        if let message =  validateView(){
            AppDelegate.sharedInstance.showAlert(message,self)
        }else{
            LocalDataManager.shared.saveProduct(name: self.txtName.text!, price: self.txtPrice.text!, provider: self.provider, description: self.tvDescription.text!)
            _ = self.navigationController?.popViewController(animated: true)
        }
        
    }
    
    @IBAction func btnUpdateClicked(_ sender : UIButton){
        if let message =  validateView(){
            AppDelegate.sharedInstance.showAlert(message,self)
        }else{
            self.productDetail.name = self.txtName.text
            self.productDetail.provider = self.provider
            self.productDetail.price = self.txtPrice.text
            self.productDetail.productDetail = self.tvDescription.text
            LocalDataManager.shared.saveContext()
            _ = self.navigationController?.popViewController(animated: true)
        }
    }
    
    @IBAction func btnDeleteClicked(_ sender : UIButton){
        LocalDataManager.shared.context.delete(self.productDetail)
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnNewProviderClicked(_ sender : UIButton){
        let newProviderVC = self.storyboard?.instantiateViewController(withIdentifier: "NewProviderVC") as! NewProviderVC
        newProviderVC.modalPresentationStyle = .overFullScreen
        self.present(newProviderVC, animated: true, completion: nil)
    }
    
    @IBAction func btnBackClicked(_ sender : UIButton){
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    //MARK:- Life cycle methods
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setUp()
    }
}


extension NewProductVC : UITextFieldDelegate{
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if textField == txtProvider{
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "SelectProviderVC") as! SelectProviderVC
            vc.selectedProvider = self.provider
            vc.providerSelected = { selectedProvider in
                self.provider = selectedProvider
                self.txtProvider.text = selectedProvider.name
            }
            self.navigationController?.pushViewController(vc, animated: true)
            return false
        }
        return true
    }
    
}
