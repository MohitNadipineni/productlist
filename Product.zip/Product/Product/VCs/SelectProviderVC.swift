//
//  SelectProviderVC.swift
//  Product
//
//  Created by Mohit
//

import UIKit

class SelectProviderVC: UIViewController {

    //MARK:- Outlets
    @IBOutlet weak var tblView : UITableView!
    
    //MARK:- Class Variables
    var providerSelected : ((ProviderTable)->())?
    var selectedProvider : ProviderTable!
    var allProviders : [ProviderTable] = []
    
    //MARK:- Custom Methods
    
    func setUp(){
        self.allProviders = LocalDataManager.shared.providers
        
        if self.selectedProvider == nil{
            self.selectedProvider = self.allProviders[0]
        }
        
        self.tblView.dataSource = self
        self.tblView.delegate = self
        self.tblView.rowHeight = UITableView.automaticDimension
        self.tblView.estimatedRowHeight = 150
        self.tblView.tableFooterView = UIView()
        
    }
    
    //MARK:- Click Events
    
    @IBAction func btnBackClicked(_ sender : UIButton){
        self.providerSelected?(self.selectedProvider)
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    //MARK:- Life cycle methods
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setUp()
    }

}


extension SelectProviderVC : UITableViewDataSource,UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.allProviders.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SelectProviderTableCell") as! SelectProviderTableCell
        cell.selectionStyle = .none
        let provider = self.allProviders[indexPath.row]
        cell.provider = provider
        cell.vwSelection.isHidden = provider != self.selectedProvider
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.selectedProvider = self.allProviders[indexPath.row]
        tableView.reloadData()
    }
}
