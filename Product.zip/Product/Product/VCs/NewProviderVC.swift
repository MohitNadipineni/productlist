//
//  NewProviderVC.swift
//  Product
//
//  Created by Mohit
//

import UIKit

class NewProviderVC: UIViewController {

    //MARK:- Outlets
    @IBOutlet weak var txtProviderName : UITextField!
    
    //MARK:- Class Variables
    
    //MARK:- Custom Methods
    
    func setUp(){
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.3)
    }
    
    //MARK:- Click Events
    
    @IBAction func btnAddClicked(_ sender : UIButton){
        if self.txtProviderName.text == ""{
            AppDelegate.sharedInstance.showAlert("Please enter provider name", self)
        }else{
            LocalDataManager.shared.addNewProvider(self.txtProviderName.text!)
            self.dismiss(animated: true, completion: nil)
        }
    }
    
    //MARK:- Life cycle methods
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setUp()
    }

}
