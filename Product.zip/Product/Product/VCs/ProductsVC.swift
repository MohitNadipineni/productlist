//
//  ProductsVC.swift
//  Product
//
//  Created by Mohit
//

import UIKit

class ProductsVC: UIViewController {

    //MARK:- Outlets
    @IBOutlet weak var tblView : UITableView!
    
    //MARK:- Class Variables
    
    var provider : ProviderTable!
    var products : [ProductTable] = []
    
    //MARK:- Custom Methods
    
    func setUp(){
        self.products = (self.provider.product?.allObjects as? [ProductTable]) ?? []
        
        self.tblView.dataSource = self
        self.tblView.delegate = self
        self.tblView.rowHeight = UITableView.automaticDimension
        self.tblView.estimatedRowHeight = 150
        self.tblView.tableFooterView = UIView()
    }
    
    //MARK:- Click Events
    
    @IBAction func backClicked(_ sender : UIButton){
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    //MARK:- Life cycle methods
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setUp()
    }

}


extension ProductsVC : UITableViewDataSource,UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.products.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ProductTableCell") as! ProductTableCell        
        cell.product = self.products[indexPath.row]
        return cell
    }
    
}
