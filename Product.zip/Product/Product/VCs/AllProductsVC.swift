//
//  AllProductsVC.swift
//  Product
//
//  Created by Mohit
//

import UIKit

class AllProductsVC: UIViewController {

    //MARK:- IBOutlets
    @IBOutlet weak var segment : UISegmentedControl!
    @IBOutlet weak var tblView : UITableView!
    @IBOutlet weak var txtSearch : UITextField!
    
    
    //MARK:- Variables
    var productList : [ProductTable] = []
    var providerList : [ProviderTable] = []
    var searchProductList : [ProductTable] = []
    var isSearch : Bool{
        if self.txtSearch.text == ""{
            return false
        }
        return true
    }
    var isProduct : Bool{
        return self.segment.selectedSegmentIndex == 0
    }
    
    //MARK:- Custom Functions
    
    func initialSetup(){
        self.segment.setTitleTextAttributes([.foregroundColor:UIColor.white], for: .selected)
        self.segment.setTitleTextAttributes([.foregroundColor:UIColor.black], for: .normal)
        //
        self.tblView.dataSource = self
        self.tblView.delegate = self
        self.tblView.rowHeight = UITableView.automaticDimension
        self.tblView.estimatedRowHeight = 150
        self.tblView.tableFooterView = UIView()
        //
        self.txtSearch.addTarget(self, action: #selector(searchTextChanged), for: .editingChanged)
    }
    
    @objc func searchTextChanged(){
        if self.txtSearch.text != ""{
            self.searchProductList = self.productList.filter({ (product) -> Bool in
                (product.name ?? "").localizedCaseInsensitiveContains(self.txtSearch.text ?? "") || (product.productDetail ?? "").localizedCaseInsensitiveContains(self.txtSearch.text ?? "")
            })
        }
        self.tblView.reloadData()
    }
    
    //MARK:- Actions
    
    @IBAction func segmentClicked(_ sender : UISegmentedControl){
        if !isProduct{
            self.searchProductList.removeAll()
            self.txtSearch.text = ""
            self.txtSearch.isHidden = true
            self.view.endEditing(true)
        }else{
            self.txtSearch.isHidden = false
        }
        self.tblView.reloadData()
    }
    
    @IBAction func addClicked(_ sender : UIButton){
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "NewProductVC") as! NewProductVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    //MARK:- Life cycle methods
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialSetup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.productList = LocalDataManager.shared.products
        self.providerList = LocalDataManager.shared.providers
        self.tblView.reloadData()
    }

}


extension AllProductsVC : UITableViewDataSource,UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isProduct{
            return isSearch ? self.searchProductList.count : self.productList.count
        }
        return providerList.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if isProduct{
            let cell = tableView.dequeueReusableCell(withIdentifier: "ProductTableCell") as! ProductTableCell
            cell.product = self.isSearch ? self.searchProductList[indexPath.row] : self.productList[indexPath.row]
            return cell
        }
        
        let providerCell = tableView.dequeueReusableCell(withIdentifier: "ProviderTableCell") as! ProviderTableCell
        providerCell.provider = self.providerList[indexPath.row]
        return providerCell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if isProduct{
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "NewProductVC") as! NewProductVC
            if isSearch{
                vc.productDetail = self.searchProductList[indexPath.row]
            }else{
                vc.productDetail = self.productList[indexPath.row]
            }
            self.txtSearch.text = ""
            self.view.endEditing(true)
            self.navigationController?.pushViewController(vc, animated: true)
        }else{
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "ProductsVC") as! ProductsVC
            vc.provider = self.providerList[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
}
